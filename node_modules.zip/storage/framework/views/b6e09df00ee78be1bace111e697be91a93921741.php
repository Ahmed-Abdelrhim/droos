<?php $__env->startSection('content'); ?>
    <div class="card-container" id="cards">
        <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card">
                <span></span>
                <span></span>
                <span></span>
                <span></span>
                <div class="card-content">
                    <img src="<?php echo e(asset('images/courses_third_year/'.$course->cover)); ?>">
                    <h2>01</h2>
                    <h3>الصف الثالث الثانوي</h3>
                    <p style="margin-top: 5px"><?php echo e($course->name); ?></p>
                    <p style="margin-top: 5px">السعر : <?php echo e($course->price); ?></p>
                    <a href="<?php echo e(route('courses.1st')); ?>">اشترك الأن</a>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
    <div class="spikes"></div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\droos\resources\views/student/all_course/third_year/3rd.blade.php ENDPATH**/ ?>