
<?php $__env->startSection('content'); ?>
    <?php if(isset($quiz)): ?>
        <section class="playlist-details">
        <div class="row">
            <div class="column">
                <div class="thumb">
                    <img src="<?php echo e(asset('images/ph-4.jpg')); ?>" alt="not-found">
                    <a href="<?php echo e($quiz); ?>" class="inline-btn"><i
                        style="margin-left:15px;" class="fas fa-clock"></i>الدخول الي الامتحان</a>
                </div>
            </div>
        </div>
    </section>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.student', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\droos\resources\views/student/enrolled/second/quiz.blade.php ENDPATH**/ ?>