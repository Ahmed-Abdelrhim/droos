<?php $__env->startSection('content'); ?>
    <section class="playlist-details">
        <div class="row">
            <div class="column">
                <div class="thumb">
                    <img src="<?php echo e(asset('images/courses_third_year/'.$course->cover)); ?>" alt="not-found">
                    <span>videos : <?php echo e(count($course['lectures'])); ?> </span>
                </div>
            </div>
            <div class="column">
                <div class="details">
                    <h3><?php echo e($course->name); ?></h3>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Illum minus reiciendis, error sunt
                        veritatis exercitationem deserunt velit doloribus itaque voluptate.
                    </p>
                </div>
                <div class="tutor">
                    <img src="<?php echo e(asset('images/courses_third_year/'.$course->cover)); ?>" alt="not-found">
                    <div class="detales">
                        <span> <i class="fas fa-book"></i> + 299   سؤال </span>
                        <span> <i class="fas fa-clock"></i> + 15   ساعة </span>
                    </div>
                </div>
                <a href="https://www.youtube.com/channel/UCXrIOiXRybTNagbllgISrDQ" class="inline-btn" target="_blank"><i
                        style="margin-left:15px;" class="fa-brands fa-youtube"></i>مشاهدة
                    الفديوهات</a>
            </div>
        </div>
    </section>
    <section class="playlist-details">
        <h2 class="heading"><span>محتوى</span> الكورس</h2>
        <div class="select-box">
            <!-- first week -->
            <button class="dropdown-btn"><i class="fa-solid fa-arrows-to-circle maine"></i>الاسبوع الاول
                <span style="display:block; font-size: 14px; color:#eee; margin-top: 15px; margin-right:15px;">محتوى الاسبوع الاول</span>
                <i class="fa fa-caret-down arrow"></i>
            </button>
            <div class="dropdown-container">
                <?php if(isset($course['lectures']) && count($course['lectures']) > 0): ?>
                    <?php $__currentLoopData = $course['lectures']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $lec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if( $lec->week == 1): ?>
                            <a href="<?php echo e(route('view.enrolled.lecture.3rd',$lec->id)); ?>">
                                <i class="fa-solid fa-video"></i>
                                <span><?php echo e($lec->name); ?></span>
                            </a>

                            <?php if($lec->homework != null): ?>
                                <a href="<?php echo e(route('view.homework.link.3rd',$lec->id)); ?>">
                                    <i class="fa-solid fa-book-open"></i>
                                    <span>واجب : <?php echo e($lec->name); ?></span></a>
                            <?php else: ?>
                                <a href="#">
                                    <i class="fa-solid fa-book-open"></i>
                                    <span>لا يوجد واجب حتي الأن</span></a>
                            <?php endif; ?>

                            <?php if($lec->quiz != null): ?>
                                <a href="<?php echo e(route('view.quiz.link.3rd',$lec->id)); ?>">
                                    <i class="fa-solid fa-chalkboard-user"></i>
                                    <span> كويز : <?php echo e($lec->name); ?></span></a>
                            <?php else: ?>
                                <a href="#">
                                    <i class="fa-solid fa-chalkboard-user"></i>
                                    <span>لا يوجد كويز حتي الأن</span></a>
                            <?php endif; ?>

                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <a href="#">
                        <i class="fa-solid fa-book-open"></i>
                        <span>لايوجد محتوي حتي الأن</span></a>
                <?php endif; ?>
            </div>
            <!-- Second Week -->
            <button class="dropdown-btn"><i class="fa-solid fa-arrows-to-circle maine"></i>الاسبوع الثاني
                <span style="display:block; font-size: 14px; color:#eee; margin-top: 15px; margin-right:15px;">
      محتوى الاسبوع الثاني</span>
                <i class="fa fa-caret-down arrow"></i>
            </button>
            <div class="dropdown-container">
                <?php if(isset($course['lectures']) && count($course['lectures']) > 0): ?>
                    <?php $__currentLoopData = $course['lectures']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $lec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if( $lec->week == 2): ?>
                            <a href="<?php echo e(route('view.enrolled.lecture.3rd',$lec->id)); ?>">
                                <i class="fa-solid fa-video"></i>
                                <span><?php echo e($lec->name); ?></span>
                            </a>

                            <?php if($lec->homework != null): ?>
                                <a href="<?php echo e(route('view.homework.link.3rd',$lec->id)); ?>">
                                    <i class="fa-solid fa-book-open"></i>
                                    <span>واجب : <?php echo e($lec->name); ?></span></a>
                            <?php else: ?>
                                <a href="#">
                                    <i class="fa-solid fa-book-open"></i>
                                    <span>لا يوجد واجب حتي الأن</span></a>
                            <?php endif; ?>

                            <?php if($lec->quiz != null): ?>
                                <a href="<?php echo e(route('view.quiz.link.3rd',$lec->id)); ?>">
                                    <i class="fa-solid fa-chalkboard-user"></i>
                                    <span> كويز : <?php echo e($lec->name); ?></span></a>
                            <?php else: ?>
                                <a href="#">
                                    <i class="fa-solid fa-chalkboard-user"></i>
                                    <span>لا يوجد كويز حتي الأن</span></a>
                            <?php endif; ?>


                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <a href="#">
                        <i class="fa-solid fa-book-open"></i>
                        <span>لايوجد محتوي حتي الأن</span></a>
                <?php endif; ?>
            </div>
            <!-- Third Week -->
            <button class="dropdown-btn"><i class="fa-solid fa-arrows-to-circle maine"></i>الاسبوع الثالث
                <span style="display:block; font-size: 14px; color:#eee; margin-top: 15px; margin-right:15px;">
      محتوى الاسبوع الثالث</span>
                <i class="fa fa-caret-down arrow"></i>
            </button>
            <div class="dropdown-container">
                <?php if(isset($course['lectures']) && count($course['lectures']) > 0): ?>
                    <?php $__currentLoopData = $course['lectures']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $lec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if( $lec->week == 3): ?>
                            <a href="<?php echo e(route('view.enrolled.lecture.3rd',$lec->id)); ?>">
                                <i class="fa-solid fa-video"></i>
                                <span><?php echo e($lec->name); ?></span>
                            </a>


                            <?php if($lec->homework != null): ?>
                                <a href="<?php echo e(route('view.homework.link.3rd',$lec->id)); ?>">
                                    <i class="fa-solid fa-book-open"></i>
                                    <span>واجب : <?php echo e($lec->name); ?></span></a>
                            <?php else: ?>
                                <a href="#">
                                    <i class="fa-solid fa-book-open"></i>
                                    <span>لا يوجد واجب حتي الأن</span></a>
                            <?php endif; ?>

                            <?php if($lec->quiz != null): ?>
                                <a href="<?php echo e(route('view.quiz.link.3rd',$lec->id)); ?>">
                                    <i class="fa-solid fa-chalkboard-user"></i>
                                    <span> كويز : <?php echo e($lec->name); ?></span></a>
                            <?php else: ?>
                                <a href="#">
                                    <i class="fa-solid fa-chalkboard-user"></i>
                                    <span>لا يوجد كويز حتي الأن</span></a>
                            <?php endif; ?>


                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <a href="#">
                        <i class="fa-solid fa-book-open"></i>
                        <span>لايوجد محتوي حتي الأن</span></a>
                <?php endif; ?>
            </div>
            <!-- Fourth Week -->
            <button class="dropdown-btn"><i class="fa-solid fa-arrows-to-circle maine"></i>الاسبوع الرابع
                <span style="display:block; font-size: 14px; color:#eee; margin-top: 15px; margin-right:15px;">
      محتوى الاسبوع الرابع</span>
                <i class="fa fa-caret-down arrow"></i>
            </button>
            <div class="dropdown-container">
                <?php if(isset($course['lectures']) && count($course['lectures']) > 0): ?>
                    <?php $__currentLoopData = $course['lectures']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $lec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if( $lec->week == 4): ?>
                            <a href="<?php echo e(route('view.enrolled.lecture.3rd',$lec->id)); ?>">
                                <i class="fa-solid fa-video"></i>
                                <span><?php echo e($lec->name); ?></span>
                            </a>

                            <?php if($lec->homework != null): ?>
                                <a href="<?php echo e(route('view.homework.link.3rd',$lec->id)); ?>">
                                    <i class="fa-solid fa-book-open"></i>
                                    <span>واجب : <?php echo e($lec->name); ?></span></a>
                            <?php else: ?>
                                <a href="#">
                                    <i class="fa-solid fa-book-open"></i>
                                    <span>لا يوجد واجب حتي الأن</span></a>
                            <?php endif; ?>

                            <?php if($lec->quiz != null): ?>
                                <a href="<?php echo e(route('view.quiz.link.3rd',$lec->id)); ?>">
                                    <i class="fa-solid fa-chalkboard-user"></i>
                                    <span> كويز : <?php echo e($lec->name); ?></span></a>
                            <?php else: ?>
                                <a href="#">
                                    <i class="fa-solid fa-chalkboard-user"></i>
                                    <span>لا يوجد كويز حتي الأن</span></a>
                            <?php endif; ?>


                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <a href="#">
                        <i class="fa-solid fa-book-open"></i>
                        <span>لايوجد محتوي حتي الأن</span></a>
                <?php endif; ?>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        var message = "This function has been disabled!";

        function clickIE4() {
            if (event.button == 2) {
                alert(message);
                return false;
            }
        }

        function clickNS4(e) {
            if (document.layers || document.getElementById && !document.all) {
                if (e.which == 2 || e.which == 3) {
                    alert(message);
                    return false;
                }
            }
        }

        if (document.layers) {
            document.captureEvents(Event.MOUSEDOWN);
            document.onmousedown = clickNS4;
        } else if (document.all && !document.getElementById) {
            document.onmousedown = clickIE4;
        }

        document.oncontextmenu = new Function("alert(message);return false")

    </script>
<?php $__env->stopSection(); ?>












<?php echo $__env->make('layouts.student', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\droos\resources\views/student/enrolled/third/week.blade.php ENDPATH**/ ?>