<?php $__env->startSection('content'); ?>
    <?php if(isset($homework)): ?>
        <section class="playlist-details">
        <div class="row">
            <div class="column">
                <div class="thumb">
                    <img src="<?php echo e(asset('images/aab.png')); ?>" alt="not-found">
                    <a href="<?php echo e($homework); ?>" class="inline-btn" target="_blank"><i
                        style="margin-left:15px;" class="fas fa-book"></i>الدخول الي الواجب</a>
                </div>
            </div>
        </div>
    </section>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        var message = "This function has been disabled!";

        function clickIE4() {
            if (event.button == 2) {
                alert(message);
                return false;
            }
        }

        function clickNS4(e) {
            if (document.layers || document.getElementById && !document.all) {
                if (e.which == 2 || e.which == 3) {
                    alert(message);
                    return false;
                }
            }
        }

        if (document.layers) {
            document.captureEvents(Event.MOUSEDOWN);
            document.onmousedown = clickNS4;
        } else if (document.all && !document.getElementById) {
            document.onmousedown = clickIE4;
        }

        document.oncontextmenu = new Function("alert(message);return false")

    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.student', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\droos\resources\views/student/enrolled/third/homework.blade.php ENDPATH**/ ?>