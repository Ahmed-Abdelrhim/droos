<?php $__env->startSection('content'); ?>
    <section class="form-container">
        <form action="<?php echo e(route('store.who.are.we')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php if(\Session::get('success')): ?>
                <div class="row mr-2 ml-2">
                    <button type="text" class="btn btn-lg btn-block btn-outline-danger mb-2"
                            id="type-error"><?php echo e(\Session::get('success')); ?>

                    </button>
                </div>
            <?php endif; ?>

            <h3>Who Are We Page</h3>

            <p>Features <span>*</span></p>
            <textarea name="text" required class="box" style="height: 300px">
                <?php if(isset($text)): ?>
                    <?php $__currentLoopData = $text; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($feat->text); ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </textarea>
            <?php $__errorArgs = ['who_are_we'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="text-danger" style="color: white"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


            <button type="submit" class="btn " style="margin-top: 30px">submit</button>
        </form>

    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\droos\resources\views/admin/who_are_we.blade.php ENDPATH**/ ?>