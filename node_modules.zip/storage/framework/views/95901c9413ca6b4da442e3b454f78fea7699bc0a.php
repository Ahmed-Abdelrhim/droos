<?php $__env->startSection('content'); ?>
    <div class="card-container" id="cards">
            <div class="card">
                <span></span>
                <span></span>
                <span></span>
                <span></span>
                <div class="card-content">
                    <img src="<?php echo e(asset('images/courses_first_year/'.$course->cover)); ?>">
                    <h2>01</h2>
                    <h3>الصف الأول الثانوي</h3>
                    <p style="margin-top: 5px"><?php echo e($course->name); ?></p>
                    <p style="margin-top: 5px">السعر : <?php echo e($course->price); ?></p>
                    <a href="<?php echo e(route('courses.1st')); ?>"></a>
                </div>
            </div>

    </div>
    <div class="spikes"></div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\droos\resources\views/student/all_course/first_year/update.blade.php ENDPATH**/ ?>