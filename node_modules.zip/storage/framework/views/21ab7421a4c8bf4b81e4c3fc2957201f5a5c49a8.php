<?php $__env->startSection('content'); ?>
    <section class="courses">
        <h1 class="heading">كورسات الصف الثالث الثانوي</h1>
        <?php if(\Session::get('success')): ?>
            <div class="row mr-2 ml-2">
                <button type="text" class="btn btn-lg btn-block btn-outline-success mb-2"
                        id="type-error"><?php echo e(\Session::get('success')); ?>

                </button>
            </div>
        <?php endif; ?>
        <div class="box-container">
            <div class="card-container" id="cards">
                <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card">
                        <span></span>
                        <span></span>
                        <span></span>
                        <span></span>
                        <div class="card-content">
                            <img src="<?php echo e(asset('images/courses_third_year/'.$course->cover)); ?>">
                            <h2>03</h2>
                            <h3>الصف الثالث الثانوي</h3>
                            <p style="margin-top: 5px"><?php echo e($course->name); ?></p>
                            <p style="margin-top: 5px">السعر : <?php echo e($course->price); ?></p>
                            <?php if(isset($serials)): ?>
                                <?php if(in_array($course->serial_number,$serials)): ?>
                                    <a href="<?php echo e(route('my.courses.3rd')); ?>">عرض الكورس</a>
                                <?php else: ?>
                                    <a href="<?php echo e(route('to.subscribe.3rd',$course->id)); ?>">اشترك الأن</a>
                                <?php endif; ?>
                            <?php else: ?>
                                <a href="<?php echo e(route('to.subscribe.3rd',$course->id)); ?>">اشترك الأن</a>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.student', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\droos\resources\views/student/all_course/3rd.blade.php ENDPATH**/ ?>