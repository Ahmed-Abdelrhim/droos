<?php $__env->startSection('content'); ?>


<section class="courses">


    <h1 class="heading"> لشراء الكورس <span style="font-size: 18px;">قم بتحويل الفلوس بفودافون كاش علي الأرقام: 01025642978</span>  </h1>

    <div class="card-container" id="cards">
        <?php if(\Session::get('success')): ?>
            <div class="row mr-2 ml-2">
                <button type="text" class="btn btn-lg btn-block btn-outline-success mb-2"
                        id="type-error"><?php echo e(\Session::get('success')); ?>

                </button>
            </div>
        <?php endif; ?>
            <div class="card">
                <span></span>
                <span></span>
                <span></span>
                <span></span>
                <div class="card-content">
                    <img src="<?php echo e(asset('images/courses_first_year/'.$course->cover)); ?>">
                    <h2>01</h2>
                    <h3>الصف الأول الثانوي</h3>
                    <p style="margin-top: 5px"> شراء <?php echo e($course->name); ?></p>
                    <p style="margin-top: 5px">السعر : <?php echo e($course->price); ?></p>
                    <form action="<?php echo e(route('subscribe.1st',$course->id)); ?>" onsubmit="return submitForm(this);" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="submit" style="cursor: pointer"/>
                    </form>
                </div>
            </div>
    </div>



</section>



<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.student', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\droos\resources\views/student/to_subscribe/1st.blade.php ENDPATH**/ ?>