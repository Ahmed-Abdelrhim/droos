
<?php $__env->startSection('content'); ?>
    <header class="header">

        <img id="back-ground" src="<?php echo e(asset('images/back-ground.png')); ?>">
        <section class="flex">

            <div class="icons">
                <div id="menu-bars" class="fas fa-bars"></div>
                <div id="toggle-btn" class="fas fa-sun"></div>
                <div id="user-btn" class="fas fa-user"></div>
            </div>


            <nav class="navbar">
                <a href="<?php echo e(route('home')); ?>" class="active"><i class="fas fa-home"></i><span>الرئيسية</span></a>
                <a href="<?php echo e(route('about')); ?>" class="active"><i class="fas fa-question"></i><span>من نحن</span></a>
                <a href="
                <?php if(Auth::check()): ?>
                <?php if(Auth::user()->academic_year == 1): ?> <?php echo e(url('courses/1st/year')); ?>

                <?php endif; ?>
                <?php if(Auth::user()->academic_year == 2): ?> <?php echo e(url('courses/2nd/year')); ?>

                <?php endif; ?>
                <?php if(Auth::user()->academic_year == 3): ?> <?php echo e(url('courses/3rd/year')); ?>

                <?php endif; ?>
                <?php else: ?> <?php echo e(route('home')); ?>

                <?php endif; ?>
                " class="active"><i class="fas fa-graduation-cap"></i><span>الكورسات</span></a>
            </nav>


            <div class="profile">
                <img src="<?php echo e(asset('images/pic-1.jpg')); ?>" class="image" alt="">
                <h3 class="name">Welcome</h3>
                <p class="role">student</p>
                <div class="flex-btn">
                    <a href="<?php echo e(route('student.login')); ?>" class="option-btn">login</a>
                    <a href="<?php echo e(route('student.register')); ?>" class="option-btn">register</a>
                </div>
            </div>
            <!-- <img id="logo-background" src="<?php echo e(asset('images/splash.png')); ?>"> -->
            <a href="<?php echo e(route('home')); ?>" class="logo"><img src="<?php echo e(asset('images/msbah.png')); ?>"></a>
        </section>

    </header>
    <section class="contact">

        <div class="row">

            <div class="image">
                <img src="<?php echo e(asset('images/contact-img.svg')); ?>" alt="not-found">
            </div>

            <form action="<?php echo e(route('msg')); ?>" method="POST">
                
                <?php if(\Session::has('success')): ?>
                    <div class="row mr-2 ml-2">
                        <button type="text" class="btn btn-lg btn-block btn-outline-success mb-2"
                                id="type-error"><?php echo e(\Session::get('success')); ?>

                        </button>
                    </div>
                <?php endif; ?>

                








                <?php echo csrf_field(); ?>
                <h3>get in touch</h3>
                
                
                
                <textarea name="msg" class="box" placeholder="enter your message" required maxlength="1000" cols="30"
                          rows="10"></textarea>
                <?php $__errorArgs = ['msg'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger" style="font-size: 20px; color: white"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <button type="submit" class="inline-btn">send message</button>
            </form>

        </div>

        <div class="box-container">

            <div class="box">
                <i class="fas fa-phone"></i>
                <h3>phone number</h3>
                <a href="tel:01152067271">01149596478</a>
            </div>

            <div class="box">
                <i class="fas fa-envelope"></i>
                <h3>email address</h3>
                <a href="mailto:eldenalaa855@gmail.com">eldenalaa855@gmail.com</a>
            </div>

            <div class="box">
                <i class="fas fa-map-marker-alt"></i>
                <h3>office address</h3>
                <a href="#">Cairo, Egypt</a>
            </div>

        </div>

    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\droos\resources\views/student/contact.blade.php ENDPATH**/ ?>