<?php $__env->startSection('content'); ?>
    <section class="form-container">
        <form action="<?php echo e(route('store.new.homework')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php if(\Session::get('success')): ?>
                <div class="row mr-2 ml-2">
                    <button type="text" class="btn btn-lg btn-block btn-outline-danger mb-2"
                            id="type-error"><?php echo e(\Session::get('success')); ?>

                    </button>
                </div>
            <?php endif; ?>

            <h3>Add New HomeWork </h3>





            <p>HomeWork Link <span>*</span></p>
            <input type="text" name="link" placeholder="enter homework link" required class="box" value="<?php echo e(old('link')); ?>">
            <?php $__errorArgs = ['link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="text-danger" style="color: white"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <p>Academic year <span>*</span></p>
            <select class="custom-select" name="academic_year" required id="academic_year">
                <option selected>...Choose</option>
                <option value="1">الصف الأول الثانوي</option>
                <option value="2">الصف الثاني الثانوي</option>
                <option value="3">الصف الثالث الثانوي</option>
            </select>

            <p>Lecture Month <span>*</span></p>
            <select class="custom-select" name="course_id" id="month">
            </select>


            <p>Lecture Week <span>*</span></p>
            <select class="custom-select" name="week" required>
                <option value="1">week 1</option>
                <option value="2">week 2</option>
                <option value="3">week 3</option>
                <option value="4">week 4</option>
            </select>
            <?php $__errorArgs = ['week'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="text-danger" style="color: white"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <button type="submit" class="btn " style="margin-top: 30px">submit</button>
        </form>

    </section>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script src="http://code.jquery.com/jquery-3.4.1.js"></script>
    <script>
        $(document).ready(function () {
            console.log('Ahmed Abdelrhim');
            $('#academic_year').on('change', function () {
                let id = $(this).val();
                $('#month').empty();
                // $('#month').append('<option value="0" disabled selected>processing ...</option>');
                $.ajax({
                    type: 'GET',
                    url: 'get/course/months/' + id ,
                    success: function (response){
                        console.log(response);
                        response = JSON.parse(response);
                        $('#month').empty();
                        $('#month').append('<option value="0" disabled selected>select month</option>');
                        response.forEach(el => {
                            $('#month').append(`<option value="${el['id']}" >${el['name']}</option>`);
                        });
                    }
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\droos\resources\views/admin/homework/add.blade.php ENDPATH**/ ?>