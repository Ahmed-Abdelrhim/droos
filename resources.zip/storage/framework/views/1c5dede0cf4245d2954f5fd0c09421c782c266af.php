<?php $__env->startSection('content'); ?>

    <header class="header">

        <img id="back-ground" src="<?php echo e(asset('images/back-ground.png')); ?>">
        <section class="flex">

            <div class="icons">
                <div id="menu-bars" class="fas fa-bars"></div>
                <div id="toggle-btn" class="fas fa-sun"></div>
                <div id="user-btn" class="fas fa-user"></div>
            </div>

            <nav class="navbar">
                <a href="<?php echo e(asset('home')); ?>" class="active"><i class="fas fa-home"></i><span>الرئيسية</span></a>
                <a href="<?php echo e(asset('about')); ?>" class="active"><i class="fas fa-question"></i><span>من نحن</span></a>
                <a href="
                <?php if(Auth::check()): ?>
                <?php if(Auth::user()->academic_year == 1): ?> <?php echo e(url('courses/1st/year')); ?>

                <?php endif; ?>
                <?php if(Auth::user()->academic_year == 2): ?> <?php echo e(url('courses/2nd/year')); ?>

                <?php endif; ?>
                <?php if(Auth::user()->academic_year == 3): ?> <?php echo e(url('courses/3rd/year')); ?>

                <?php endif; ?>
                <?php else: ?> <?php echo e(route('home')); ?>

                <?php endif; ?>
            " class="active"><i class="fas fa-graduation-cap"></i><span>الكورسات</span></a>
                <a href="<?php echo e(asset('contact')); ?>" class="active"><i class="fas fa-headset"></i><span>تواصل معنا</span></a>
            </nav>


            <div class="profile">
                <img class="image" src="<?php if(Auth::check()): ?>
                  <?php echo e(asset('images/studentImages/'.Auth::user()->avatar)); ?>

                  <?php else: ?>
                  <?php echo e(asset('images//pic-6.jpg')); ?>

                  <?php endif; ?>" alt="tutor">
                <h3 class="name">
                    <?php if(Auth::check()): ?>
                        <?php echo e(Auth::user()->name); ?>

                    <?php else: ?>
                        Student
                    <?php endif; ?>
                </h3>
                <p class="role">student</p>
                <?php if(Auth::check()): ?>
                    <form method="GET" action="<?php echo e(route('view.student.profile')); ?>">
                        <?php echo csrf_field(); ?>
                        <button class="btn" type="submit">view profile</button>
                    </form>
                    <form method="POST" action="<?php echo e(route('student.logout')); ?>">
                        <?php echo csrf_field(); ?>
                        <button class="btn" type="submit">log out</button>
                    </form>
                <?php else: ?>
                    <a href="<?php echo e(route('student.login')); ?>" class="option-btn">login</a>
                    <a href="<?php echo e(route('student.register')); ?>" class="option-btn">register</a>
                <?php endif; ?>

                
                
                
                
                
                
                
            </div>
            <!-- <img id="logo-background" src="<?php echo e(asset('images/splash.png')); ?>"> -->
            <a href="<?php echo e(asset('home')); ?>" class="logo"><img src="<?php echo e(asset('images/msbah.png')); ?>"></a>
        </section>

    </header>



    <section class="about">

        <div class="row">

            <div class="image">
                <img src="<?php echo e(asset('images/about-img.svg')); ?>" alt="">
            </div>

            <div class="content">
                <h3>لماذا تختار منصتنا ؟ </h3>
                <p>
                    <?php if(isset($who_are_we)): ?>
                        <?php $__currentLoopData = $who_are_we; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $text): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($text->text); ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        Lorem ipsum dolor sit amet consectetur, adipisicing elit. Ut dolorum quasi illo? Distinctio
                        expedita commodi, nemo a quam error repellendus sint, fugiat quis numquam eum eveniet sequi
                        aspernatur quaerat tenetur.
                    <?php endif; ?>

                </p>

                <a href="<?php echo e(route('home')); ?>" class="inline-btn">our courses</a>
            </div>

        </div>

        <div class="box-container">

            <div class="box">
                <i class="fas fa-graduation-cap"></i>
                <div>
                    <h3>+50</h3>
                    <p>online courses</p>
                </div>
            </div>

            <div class="box">
                <i class="fas fa-user-graduate"></i>
                <div>
                    <h3>+1k</h3>
                    <p>brilliant students</p>
                </div>
            </div>

            
            
            
            
            
            
            

            <div class="box">
                <i class="fas fa-briefcase"></i>
                <div>
                    <h3>100%</h3>
                    <p>time quality</p>
                </div>
            </div>

        </div>

    </section>


    

    

    

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

    

    






    <!-- Start Footer -->
    <footer class="footer">
        <div class="container">
            <div class="box">
                <a href="<?php echo e(route('home')); ?>" class="logo"><img src="<?php echo e(asset('images/logo.png')); ?>"></a>
                <ul class="social">
                    <li>
                        <a href="https://www.facebook.com/profile.php?id=100068906257005" class="facebook"
                           target="_blank">
                            <i class="fab fa-facebook-f"></i>
                        </a>
                    </li>
                    <li>
                        <a href="https://web.facebook.com/profile.php?id=100009262544420" class="twitter"
                           target="_blank">
                            <i class="fab fa-twitter"></i>
                        </a>
                    </li>
                    <li>
                        <a href="https://www.youtube.com/channel/UCXrIOiXRybTNagbllgISrDQ" class="youtube"
                           target="_blank">
                            <i class="fab fa-youtube"></i>
                        </a>
                    </li>
                </ul>
                <p class="text">
                    منصة علاء الدين لشرح منهج الفزياء للثانوية العامة
                </p>
            </div>
            <div class="box">
                <ul class="links">
                    <li><a href="<?php echo e(route('home')); ?>">الرئيسية</a></li>
                    <li><a href="<?php echo e(route('about')); ?>">من نحن</a></li>
                    <li><a href="<?php echo e(route('contact')); ?>">تواصل معنا</a></li>
                    <li><a href="<?php echo e(route('home')); ?>">الكورسات</a></li>
                </ul>
            </div>
            <div class="box">
                <div class="line">
                    <i class="fas fa-map-marker-alt fa-fw"></i>
                    <div class="info">مصر</div>
                </div>
                <div class="line">
                    <i class="far fa-clock fa-fw"></i>
                    <div class="info">24/7</div>
                </div>
                <div class="line">
                    <i class="fas fa-phone-volume fa-fw"></i>
                    <div class="info">01149596478</div>
                </div>
            </div>
            <div class="box footer-gallery">
                <img src="<?php echo e(asset('images/thumb-9.png')); ?>" alt=""/>
                <img src="<?php echo e(asset('images/thumb-8.png')); ?>" alt=""/>
                <img src="<?php echo e(asset('images/year-2.jpeg')); ?>" alt=""/>
                <img src="<?php echo e(asset('images/ph-1.jpg')); ?>" alt=""/>
                <img src="<?php echo e(asset('images/thumb-5.png')); ?>" alt=""/>
                <img src="<?php echo e(asset('images/thumb-4.png')); ?>" alt=""/>
            </div>
            <!-- <div class="box">
                <p class="text">
                    للتواصل مع مطوري الموقع يرجي الاتصال علي الارقام التالية
                </p>
                <div class="line">
                    <i class="fas fa-phone-volume fa-fw"></i>
                    <div class="info">01152067271</div>
                    <i class="fas fa-phone-volume fa-fw"></i>
                    <div class="info">01014012312</div>
                </div>
            </div> -->
        </div>
        <p class="copyright">Developed  <a href="https://www.facebook.com/ahmed.abdalraheem.739" class="fas fa-heart"
                                             target="_blank"></a>
            By
            <a href="https://www.facebook.com/ahmed.abdalraheem.739" target="_blank">
        <p>Ahmed Abdelrhim</p>
        <p><a href="tel:01152067271" style="text-decoration: none; color: #8e44ad;">01152067271</a></p>
        </a> ,
        <a href="https://www.facebook.com/anas.rabea.35" target="_blank">
            <p>Anas Rabea</p>
            <p><a href="tel:01014012312" style="text-decoration: none; color: #8e44ad;">01014012312</a></p>
        </a>
        </p>
        &copy; copyright @ 2022 | all rights reserved!
    </footer>

    <!-- scroll top button  -->
    <a href="#" class="top">
        <img src="images/scroll-top-img.png">
    </a>
    <!-- End Footer -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\droos\resources\views/student/about.blade.php ENDPATH**/ ?>