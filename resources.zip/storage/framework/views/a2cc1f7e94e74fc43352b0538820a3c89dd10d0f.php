<?php $__env->startSection('content'); ?>
    <section class="courses">
        <?php if(\Session::get('success')): ?>
            <div class="row mr-2 ml-2">
                <button type="text" class="btn btn-lg btn-block btn-outline-success mb-2"
                        id="type-error"><?php echo e(\Session::get('success')); ?>

                </button>
            </div>
        <?php endif; ?>
        <h1 class="heading">HomeWorks Secondary Second Year</h1>

        <div class="box-container" style="overflow-x:auto;">
            <table>
                
                <thead class="scroll-horizontal">
                <tr>
                    <th>course name </th>
                    <th>course month</th>
                    <th>week </th>
                    <th>link </th>
                    <th>Action</th>
                </tr>
                </thead>
                
                
                <tbody>

                <?php $__currentLoopData = $homeworks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $work): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($work['course']->name); ?></td>
                        <td><?php echo e($work->serial_number); ?></td>
                        <td><?php echo e($work->week); ?></td>
                        <td><?php echo e($work->link); ?></td>
                        <td style="width: 130px; height: 30px">
                            <form action="<?php echo e(route('delete.homework.2nd',$work->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <button class="btn btn-danger" style="background-color: #dc3545;">delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                
            </table>
        </div>

        <div class="custom-pagination"> <?php echo e($homeworks->links()); ?> </div>

    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\droos\resources\views/admin/homework/2nd.blade.php ENDPATH**/ ?>