
<?php $__env->startSection('content'); ?>
<section class="courses">

<h1 class="heading">كورسات الصف الأول الثانوي</h1>

<div class="box-container">


    <div class="card-container" id="cards">
        <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card">
                <span></span>
                <span></span>
                <span></span>
                <span></span>
                <div class="card-content">
                    <img src="<?php echo e(asset('images/courses_second_year/'.$course->cover)); ?>">
                    <h2>02</h2>
                    <h3>الصف الثاني الثانوي</h3>
                    <p style="margin-top: 5px"><?php echo e($course->name); ?></p>
                    <p style="margin-top: 5px">السعر : <?php echo e($course->price); ?></p>
                    <a href="<?php echo e(route('edit.course.2nd',$course->id)); ?>" class="btn btn-primary" >edit course</a>
                    <form action="<?php echo e(route('delete.course.2nd',$course->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <button class="btn btn-danger">delete course</button>
                    </form>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

</div>

</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\droos\resources\views/admin/courses/second_year/index.blade.php ENDPATH**/ ?>