<?php $__env->startSection('content'); ?>
    <div class="card-container" id="cards" style="background-color: white">
        <div class="card">
            <div class="card-content">
                <img src="<?php echo e(asset('images/access-denied.jpg')); ?>">
                <h2>Page Not Found</h2>
                
                
            </div>
        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\droos\resources\views/student/access_denied.blade.php ENDPATH**/ ?>