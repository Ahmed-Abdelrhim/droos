<?php $__env->startSection('content'); ?>
    <section class="courses">
        <?php if(\Session::get('success')): ?>
            <div class="row mr-2 ml-2">
                <button type="text" class="btn btn-lg btn-block btn-outline-success mb-2"
                        id="type-error"><?php echo e(\Session::get('success')); ?>

                </button>
            </div>
        <?php endif; ?>

        <h1 class="heading">Waiting List Secondary Second Year</h1>

        <div class="box-container" style="overflow-x:auto;">
            <table>
                <thead>
                <tr>
                    <th>Student Name</th>
                    <th>Student Email</th>
                    <th>Student Phone</th>
                    <th>Student Parent Phone</th>
                    <th>Course Month</th>
                    <th>Actions</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $allData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th><?php echo e($data['students']->name); ?></th>
                        <th><?php echo e($data['students']->email); ?></th>
                        <th><?php echo e($data['students']->phone_number); ?></th>
                        <th><?php echo e($data['students']->parent_number); ?></th>
                        <th><?php echo e($data->serial_number); ?></th>                        <th style="width: 130px; height: 30px">
                            <form action="<?php echo e(route('activate.waiting.2nd',$data->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <button class="btn btn-primary" style="background-color: #007bff;border-color: #007bff">
                                    Activate
                                </button>
                            </form>
                            <form action="<?php echo e(route('delete.waiting.2nd',$data->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <button class="btn btn-danger" style="background-color: #dc3545;">Delete</button>
                            </form>
                        </th>
                        </th>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
            <div class="custom-pagination"> <?php echo e($allData->links()); ?> </div>

    </section>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\droos\resources\views/admin/waiting_list/second/index.blade.php ENDPATH**/ ?>